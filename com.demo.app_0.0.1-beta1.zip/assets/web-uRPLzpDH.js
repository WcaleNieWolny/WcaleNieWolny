import{u as e}from"./index-Cn0Lx_6n.js";class r extends e{}export{r as CapacitorShakeWeb};
